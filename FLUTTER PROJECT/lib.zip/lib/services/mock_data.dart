
class MockNewsData {
  static final List<Map<String, dynamic>> mockArticles = [
    {
      "source": {"id": "mock-source-1", "name": "Tech Daily"},
      "author": "Jane Smith",
      "title": "New Advances in AI Technology Reshape Industry Standards",
      "description": "Recent breakthroughs in artificial intelligence are changing how companies approach automation and data analysis.",
      "url": "https://example.com/tech-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5",
      "publishedAt": "2025-03-25T10:30:00Z",
      "content": "Artificial intelligence continues to evolve at a rapid pace, with new algorithms and models being developed that significantly outperform previous generations of AI technology..."
    },
    {
      "source": {"id": "mock-source-2", "name": "Climate Report"},
      "author": "John Johnson",
      "title": "Global Weather Patterns Show Concerning Trends",
      "description": "Scientists analyze data from the past decade showing accelerating changes in weather systems worldwide.",
      "url": "https://example.com/weather-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1504608524841-42fe6f032b4b",
      "publishedAt": "2025-03-24T08:45:00Z",
      "content": "Analysis of global weather data from the past decade reveals concerning trends in temperature variations and extreme weather events..."
    },
    {
      "source": {"id": "mock-source-3", "name": "Business Insider"},
      "author": "Sarah Williams",
      "title": "Market Volatility Increases as Global Tensions Rise",
      "description": "Financial markets respond to international developments with increased uncertainty.",
      "url": "https://example.com/business-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3",
      "publishedAt": "2025-03-23T14:20:00Z",
      "content": "Stock markets worldwide experienced significant fluctuations this week as investors responded to developing international situations..."
    },
    {
      "source": {"id": "mock-source-4", "name": "Health Today"},
      "author": "Dr. Michael Chen",
      "title": "New Research Reveals Benefits of Mediterranean Diet",
      "description": "Long-term study confirms positive effects on cardiovascular health and longevity.",
      "url": "https://example.com/health-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
      "publishedAt": "2025-03-22T11:15:00Z",
      "content": "A 15-year study following over 10,000 participants has provided strong evidence supporting the health benefits of the Mediterranean diet..."
    },
    {
      "source": {"id": "mock-source-5", "name": "Sports Center"},
      "author": "Kevin Johnson",
      "title": "International Soccer Tournament Draws Record Viewership",
      "description": "The championship match broke streaming records across multiple platforms.",
      "url": "https://example.com/sports-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1521731978332-9e9e714bdd20",
      "publishedAt": "2025-03-21T19:30:00Z",
      "content": "The final match of this year's international soccer tournament has become the most-watched sporting event in streaming history..."
    },
    {
      "source": {"id": "mock-source-6", "name": "Science Daily"},
      "author": "Dr. Emily Roberts",
      "title": "Astronomers Discover Potentially Habitable Exoplanet",
      "description": "New planet in the habitable zone of its star shows promising signs for supporting life.",
      "url": "https://example.com/science-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1538370965046-79c0d6907d47",
      "publishedAt": "2025-03-20T16:45:00Z",
      "content": "Using advanced observation techniques, astronomers have identified a new exoplanet that orbits within the habitable zone of its star..."
    },
    {
      "source": {"id": "mock-source-7", "name": "Entertainment Weekly"},
      "author": "Robert Anderson",
      "title": "Highly Anticipated Film Sequel Breaks Opening Weekend Records",
      "description": "The long-awaited sequel surpassed box office predictions in its first weekend.",
      "url": "https://example.com/entertainment-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1536440136628-849c177e76a1",
      "publishedAt": "2025-03-19T13:10:00Z",
      "content": "After years of anticipation, the sequel to the blockbuster film has shattered opening weekend records, bringing in over 300 million dollars globally..."
    },
    {
      "source": {"id": "mock-source-8", "name": "Tech Review"},
      "author": "Thomas Lee",
      "title": "New Smartphone Features Focus on Privacy and Security",
      "description": "Leading manufacturers announce enhanced security measures in upcoming models.",
      "url": "https://example.com/tech-news-2",
      "urlToImage": "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c",
      "publishedAt": "2025-03-18T09:25:00Z",
      "content": "The next generation of smartphones will feature significantly improved privacy controls and security features according to announcements from leading manufacturers..."
    },
    {
      "source": {"id": "mock-source-9", "name": "Education Journal"},
      "author": "Dr. Amanda Carter",
      "title": "Study Shows Benefits of Blended Learning Approaches",
      "description": "Research indicates combining online and in-person education yields best results for students.",
      "url": "https://example.com/education-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1503676260728-1c00da094a0b",
      "publishedAt": "2025-03-17T15:50:00Z",
      "content": "A comprehensive study of educational outcomes has found that approaches combining traditional classroom instruction with online learning components show superior results..."
    },
    {
      "source": {"id": "mock-source-10", "name": "Travel Guide"},
      "author": "Maria Garcia",
      "title": "Sustainable Tourism Trends Reshape Travel Industry",
      "description": "Eco-friendly travel options gain popularity as environmental awareness increases.",
      "url": "https://example.com/travel-news-1",
      "urlToImage": "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
      "publishedAt": "2025-03-16T12:35:00Z",
      "content": "The travel industry is experiencing a significant shift toward sustainable tourism options as travelers increasingly prioritize environmental considerations in their vacation planning..."
    }
  ];

  static List<Map<String, dynamic>> getMockArticlesByCategory(String category) {
    // Simple filtering based on article title or content containing the category keyword
    return mockArticles.where((article) {
      final title = article['title'].toString().toLowerCase();
      final content = article['content'].toString().toLowerCase();
      final categoryLower = category.toLowerCase();
      return title.contains(categoryLower) || content.contains(categoryLower);
    }).toList();
  }

  static List<Map<String, dynamic>> searchMockArticles(String query) {
    // Simple search in title, description and content
    return mockArticles.where((article) {
      final title = article['title'].toString().toLowerCase();
      final description = article['description'].toString().toLowerCase();
      final content = article['content'].toString().toLowerCase();
      final queryLower = query.toLowerCase();
      return title.contains(queryLower) || 
             description.contains(queryLower) || 
             content.contains(queryLower);
    }).toList();
  }
}
