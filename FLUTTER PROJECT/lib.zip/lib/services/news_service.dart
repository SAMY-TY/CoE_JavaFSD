import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/article.dart';
import 'package:intl/intl.dart';
import 'mock_data.dart';

class NewsService {

  static const String _apiKey = '';
  static const String _baseUrl = 'https://newsapi.org/v2';
  
 
  bool _useMockData = true;

  // Get formatted date for 'from' parameter (7 days ago)
  String _getFromDate() {
    final DateTime now = DateTime.now();
    final DateTime weekAgo = now.subtract(const Duration(days: 7));
    return DateFormat('yyyy-MM-dd').format(weekAgo);
  }

  // Fetch top headlines (limited to 5 articles)
  Future<List<Article>> getTopHeadlines() async {
    if (_useMockData) {
      return _getMockTopHeadlines();
    }
    
    try {
      final fromDate = _getFromDate();
      final response = await http.get(
        Uri.parse('$_baseUrl/everything?q=news&from=$fromDate&sortBy=popularity&pageSize=5&apiKey=$_apiKey'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> articlesJson = jsonData['articles'];
        return articlesJson.map((article) => Article.fromJson(article)).toList();
      } else {
        // Fallback to mock data on API error
        return _getMockTopHeadlines();
      }
    } catch (e) {
      // Fallback to mock data on exception
      return _getMockTopHeadlines();
    }
  }

  // Fetch news by category (limited to 10 articles)
  Future<List<Article>> getNewsByCategory(String category) async {
    if (_useMockData) {
      return _getMockNewsByCategory(category);
    }
    
    try {
      final fromDate = _getFromDate();
      final response = await http.get(
        Uri.parse('$_baseUrl/everything?q=$category&from=$fromDate&sortBy=popularity&pageSize=10&apiKey=$_apiKey'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> articlesJson = jsonData['articles'];
        return articlesJson.map((article) => Article.fromJson(article)).toList();
      } else {
        // Fallback to mock data on API error
        return _getMockNewsByCategory(category);
      }
    } catch (e) {
      // Fallback to mock data on exception
      return _getMockNewsByCategory(category);
    }
  }

  // Search news (limited to 10 articles)
  Future<List<Article>> searchNews(String query) async {
    if (_useMockData) {
      return _searchMockNews(query);
    }
    
    try {
      final fromDate = _getFromDate();
      final response = await http.get(
        Uri.parse('$_baseUrl/everything?q=$query&from=$fromDate&sortBy=popularity&pageSize=10&apiKey=$_apiKey'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> articlesJson = jsonData['articles'];
        return articlesJson.map((article) => Article.fromJson(article)).toList();
      } else {
        // Fallback to mock data on API error
        return _searchMockNews(query);
      }
    } catch (e) {
      // Fallback to mock data on exception
      return _searchMockNews(query);
    }
  }

  // Mock data methods
  List<Article> _getMockTopHeadlines() {
    // Get the first 5 mock articles
    final mockArticles = MockNewsData.mockArticles.take(5).toList();
    return mockArticles.map((article) => Article.fromJson(article)).toList();
  }

  List<Article> _getMockNewsByCategory(String category) {
    final mockArticles = MockNewsData.getMockArticlesByCategory(category);
    return mockArticles.map((article) => Article.fromJson(article)).toList();
  }

  List<Article> _searchMockNews(String query) {
    final mockArticles = MockNewsData.searchMockArticles(query);
    return mockArticles.map((article) => Article.fromJson(article)).toList();
  }
}
